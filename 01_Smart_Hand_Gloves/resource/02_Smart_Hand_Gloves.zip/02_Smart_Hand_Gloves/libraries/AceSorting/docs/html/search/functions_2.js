var searchData=
[
  ['insertionsort_40',['insertionSort',['../insertionSort_8h.html#aac763b62e542f9b96b393fc633af0a3b',1,'ace_sorting::insertionSort(T data[], uint16_t n)'],['../insertionSort_8h.html#a0b8e2cd45c85523728e9611abfca83c9',1,'ace_sorting::insertionSort(T data[], uint16_t n, F &amp;&amp;lessThan)']]]
];
