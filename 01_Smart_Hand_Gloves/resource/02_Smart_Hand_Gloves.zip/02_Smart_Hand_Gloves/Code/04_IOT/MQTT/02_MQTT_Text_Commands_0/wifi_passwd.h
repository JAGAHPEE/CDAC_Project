// WiFi Credentials....
const char* ssid = "TP-Link_AOSR";
const char* password = "7979853506";
const char* mqtt_server = "192.168.0.101";
const int mqtt_port = 1883;
const char* mqtt_username = "root";
const char* mqtt_password = "cdac@123";