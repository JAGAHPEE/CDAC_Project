//---- WiFi settings
const char* ssid = "TP-Link_AOSR";
const char* password = "7979853506";
const char* mqttServer = "f1c4d286c90e439b89d27d4fda3188f6.s1.eu.hivemq.cloud";
const char* mqttUsername = "sandesh_kale_66";
const char* mqttPassword = "Sandesh@123";
int mqttPort = 8883;