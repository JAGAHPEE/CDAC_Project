enum Track_Playback {
  INIT_TRACK = 1,
  C_ERROR = 2,
  MEDICINE = 3,
  FOOD_RES = 4,
  WATER_RES = 5,
  WATER_REQ = 6,
  FOOD_REQ = 7,
  NEED_HELP = 8,
  KEEP_FS = 9,
};