// DF Mini Player
#include "SoftwareSerial.h"
#include "DFRobotDFPlayerMini.h"
// Use pins 2 and 3 to communicate with DFPlayer Mini
static const uint8_t PIN_MP3_TX = 17;  // Connects to module's RX
static const uint8_t PIN_MP3_RX = 16;  // Connects to module's TX
SoftwareSerial softwareSerial(PIN_MP3_RX, PIN_MP3_TX);
// Create the Player object
DFRobotDFPlayerMini player;
int option = 1;

// OLED Display
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128  // OLED display width, in pixels
#define SCREEN_HEIGHT 64  // OLED display height, in pixels

#define OLED_RESET -1        // Reset pin # (or -1 if sharing Arduino reset pin)
#define SCREEN_ADDRESS 0x3C  ///< See datasheet for Address; 0x3D for 128x64, 0x3C for 128x32
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Sensor Data Analog Read and Pin Defining
int sensorPin_1 = 36;   // select the input pin for the potentiometer
int sensorPin_2 = 39;   // select the input pin for the potentiometer
int sensorPin_3 = 34;   // select the input pin for the potentiometer
int ledPin = 2;         // select the pin for the LED
int sensorValue_1 = 0;  // variable to store the value coming from the sensor
int sensorValue_2 = 0;  // variable to store the value coming from the sensor
int sensorValue_3 = 0;  // variable to store the value coming from the sensor
