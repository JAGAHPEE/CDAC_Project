#define test_count 4

int MAX_1 = 0;
int MAX_2 = 0;
int MAX_3 = 0;
int MIN_1 = 0;
int MIN_2 = 0;
int MIN_3 = 0;

uint8_t flag_for_min_max = 0;
