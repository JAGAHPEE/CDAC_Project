enum Track_Playback {
  INIT_TRACK = 1,
  MEDICINE = 2,
  FOOD_RES = 3,
  WATER_RES = 4,
  FOOD_REQ = 5,
  NEED_HELP = 6,
  WATER_REQ = 7,
  C_ERROR = 8,
  KEEP_FS = 9,
};