#include "esp32-hal.h"
#include "esp32-hal-gpio.h"
// Sensor Pin Number Declaration
// ctrl + alt + k to open the location of project
const int sensor_Pin_1 = 34;
const int sensor_Pin_2 = 39;
const int sensor_Pin_3 = 36;

// LED Pin
const int LED = 2;



