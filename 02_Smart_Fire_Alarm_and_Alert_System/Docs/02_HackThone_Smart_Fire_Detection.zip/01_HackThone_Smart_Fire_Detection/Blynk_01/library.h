

#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL3usWQkCit"
#define BLYNK_TEMPLATE_NAME "CDAC"
#define BLYNK_AUTH_TOKEN "Ju3IUmzw52GIXlbs151sVfZWaIBM4oS6"

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>
// Your WiFi credentials.
// Set password to "" for open networks.
char ssid[] = "TP-Link_AOSR";
char pass[] = "7979853506";


#define SCREEN_WIDTH 128  // OLED display width, in pixels
#define SCREEN_HEIGHT 64  // OLED display height, in pixels

#define OLED_RESET -1        // Reset pin # (or -1 if sharing Arduino reset pin)
#define SCREEN_ADDRESS 0x3C  ///< See datasheet for Address; 0x3D for 128x64, 0x3C for 128x32
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

#define LED 2
#define FLAME 34
#define SWITCH 15

#define DHTPIN 4
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

float f;
float t;
float h;
float humidity;
uint16_t f_light;

uint8_t next = 10;
uint8_t prev = 10;
uint8_t d = 0;
void get_value_from_sensor();
void OLD_Display(float, float, float, int);
